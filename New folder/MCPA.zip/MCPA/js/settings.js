﻿var BookIt = BookIt || {};
BookIt.Settings = BookIt.Settings || {};
BookIt.Settings.signUpUrl =  "http://www.mobile4fun.in/MCPA/api/v1/signup";
BookIt.Settings.signUpAdminUrl =  "http://www.mobile4fun.in/MCPA/api/v1/signupAdmin";
BookIt.Settings.signInUrl =  "http://www.mobile4fun.in/MCPA/api/v1/login";
BookIt.Settings.userDetails =  "http://www.mobile4fun.in/MCPA/api/v1/details";
BookIt.Settings.newClaim =  "http://www.mobile4fun.in/MCPA/api/v1/newClaim";
BookIt.Settings.pendingClaim =  "http://www.mobile4fun.in/MCPA/api/v1/pendingClaim";
BookIt.Settings.allPendingClaim = "http://www.mobile4fun.in/MCPA/api/v1/allPendingClaim";
BookIt.Settings.completedClaim =  "http://www.mobile4fun.in/MCPA/api/v1/completedClaim";
BookIt.Settings.allCompletedClaim =  "http://www.mobile4fun.in/MCPA/api/v1/allCompletedClaim";
BookIt.Settings.allUsers =  "http://www.mobile4fun.in/MCPA/api/v1/allUsers";

BookIt.Settings.approveDecline =  "http://www.mobile4fun.in/MCPA/api/v1/approveDecline";
BookIt.Settings.search =  "http://www.mobile4fun.in/MCPA/api/v1/search";